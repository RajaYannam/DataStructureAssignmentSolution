package com.greatlearning.ds.service;

import java.util.PriorityQueue;

public class Service {

	public void Service(int noofFloors, int[] floors) {
		// TODO Auto-generated constructor stub	
		System.out.println("The order of construction is as follows");
	   
	PriorityQueue<Integer> queue=new PriorityQueue<>(java.util.Collections.reverseOrder());
	 int temp[]=new int[noofFloors];
	 int max=noofFloors;
	   
	 System.out.println();
	for(int j=0;j<noofFloors;j++) {
		System.out.println("Day:"+ (j+1));
		 temp[j]=floors[j];
		 queue.add(temp[j]);
		 
		 while(!(queue.isEmpty()) && queue.peek()== max) {
			 System.out.print(queue.poll() +" ");
			 max--;
		 }
		 System.out.println();
          		
	}
	
	
}

}
