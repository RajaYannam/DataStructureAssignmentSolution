package com.greatlearning.ds.driver;

import java.io.IOException;
import java.util.Scanner;

import com.greatlearning.ds.service.Service;

public class Driver {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the total no of floors in the building");
		int NoofFloors=sc.nextInt();
		int Floors[]=new int[NoofFloors];
		
		System.out.println();
		for(int i=0;i<NoofFloors;i++) {
			System.out.println("Enter the Floorsize given on Day : " + (i+1));	
			Floors[i]=sc.nextInt();
		}
		System.out.println();
		
		Service service=new Service();
		service.Service(NoofFloors,Floors);

	}

}
